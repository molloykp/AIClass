cp ~/DeveloperM/pythondev/cs445/PA00/text_gen_tests.py .
cp ~/DeveloperM/pythondev/cs445/PA00/unittest_utils.py .

