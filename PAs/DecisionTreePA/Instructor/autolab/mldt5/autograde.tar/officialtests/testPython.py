import numpy as np
print('Hello, world!')
