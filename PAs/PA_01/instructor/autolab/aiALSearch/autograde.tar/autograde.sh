#!/bin/bash


### Unzip file
### 
###

unzip -j pa1.zip 

if [ ! -r search.py -o ! -r searchAgents.py ]
then
  echo Either search.py and/or searchAgents.py is not contained
  echo within the zipfile pa1.zip
  exit 0
fi

cp -R scaffolding/* working
mv search.py searchAgents.py working
cd working

echo "Testing your code..."

python3 autograder.py > grade.log 2> grade.err

cat grade.log grade.err

q1S=`cat grade.log | grep "^Question q1:" | cut -c 13- | cut -d \/ -f 1`
q2S=`cat grade.log | grep "^Question q2:" | cut -c 13- | cut -d \/ -f 1`
q3S=`cat grade.log | grep "^Question q3:" | cut -c 13- | cut -d \/ -f 1`
q4S=`cat grade.log | grep "^Question q4:" | cut -c 13- | cut -d \/ -f 1`
q5S=`cat grade.log | grep "^Question q5:" | cut -c 13- | cut -d \/ -f 1`
q6S=`cat grade.log | grep "^Question q6:" | cut -c 13- | cut -d \/ -f 1`
q7S=`cat grade.log | grep "^Question q7:" | cut -c 13- | cut -d \/ -f 1`
q8S=`cat grade.log | grep "^Question q8:" | cut -c 13- | cut -d \/ -f 1`


echo

echo {\"scores\": {\"q1\":${q1S}, \"q2\":${q2S}, \"q3\":${q3S}, \"q4\":${q4S}, \"q5\":${q5S}, \"q6\":${q6S}, \"q7\":${q7S}, \"q8\":${q8S}}}

exit 0
